<script setup lang="ts">

</script>

<template>
  <div class="flex flex-col mob:px-[16px] mob:py-[64px] mob:gap-[32px] px-[485px] py-[120px] gap-[48px]">
    <div class="mob:w-[328px] mob:h-[250px] flex w-[950px] h-[596px] relative">
      <div class="mob:w-[300px] mob:h-[220px] image-wrapper w-[710px] h-[520px] relative z-0">
        <img
          src="../assets/images/img_9.png"
          alt="loading..."
        >
      </div>
      <div class="w-[488px] h-[368px] mob:h-[172px] mob:w-[183px] mob:p-[16px] text-[64px] mob:text-[30px] mob:leading-[36px] leading-[64px] relative z-10 uppercase text-center p-[48px] bg-[#2E2F30] mob:ml-[-155px] ml-[-248px] text-[#FFF]">
        <h1 class="flex flex-wrap border-solid border-2 border-white items-center h-[100%] w-[100%]">
          Think outside the box
        </h1>
      </div>
    </div>

    <div class="flex flex-col gap-[32px]">
      <div class="flex flex-col gap-[24px] mob:gap-[12px]">
        <div class="flex items-center gap-[24px] mob:items-start mob:gap-[12px]">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            class="mob:h-[16px] mob:w-[16px]"
          >
            <path
              d="M23.875 24L0.301777 24C0.190414 24 0.134642 23.8654 0.213388 23.7866L23.7866 0.213387C23.8654 0.134643 24 0.190411 24 0.301776L24 23.875C24 23.944 23.944 24 23.875 24Z"
              fill="#147CD1"
            />
          </svg>
          <h1 class="font-bold text-[48px] leading-[64px] mob:text-center mob:text-[30px] mob:leading-[36px] mob:mt-[-6px]">
            Short History
          </h1>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            class="mob:h-[16px] mob:w-[16px]"
          >
            <path
              d="M0 23.875V0.301777C0 0.190414 0.134642 0.134642 0.213388 0.213388L23.7866 23.7866C23.8654 23.8654 23.8096 24 23.6982 24H0.125C0.0559644 24 0 23.944 0 23.875Z"
              fill="#147CD1"
            />
          </svg>
        </div>
        <div class="text-[24px] text-[#565656] leading-[32px] mob:text-[16px] mob:leading-[24px]">
          Efficiency and precision are the cornerstone of a successful workflow, where collaboration and dedication intertwine to achieve outstanding results.Efficiency and precision are the cornerstone of a successful workflow,
          where collaboration and dedication intertwine to achieve outstanding results
        </div>
      </div>
      <div>
        <button class="flex items-center gap-[10px] border-solid border-[1px] border-black px-[16px] py-[12px]">
          <span class="text-[16px]">Read More</span>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="none"
          >
            <path
              d="M4.00016 4V5.33333H9.72683L3.3335 11.7267L4.2735 12.6667L10.6668 6.27333V12H12.0002V4H4.00016Z"
              fill="#262626"
            />
          </svg>
        </button>
      </div>
    </div>
  </div>
</template>
