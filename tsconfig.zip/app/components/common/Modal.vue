<script setup lang="ts">

</script>

<template>
  <div>
    <div class="text-[50px] items-center flex-center">This is dynamic modal Title</div>
    <div class="text-[20px] items-center flex-center">This is dynamic modal body</div>
  </div>
</template>

<style scoped>

</style>