<script setup lang="ts">

</script>

<template>
  <div class="flex items-center justify-center mob:py-[64px] mob:px-[16px] mob:gap-[32px] gap-[48px] flex-col py-[120px]">
    <div class="flex justify-center items-center flex-col gap-[16px] mob:gap-[12px] mob:px-[16px]">
      <div class="flex gap-[24px] items-center mob:items-start mob:gap-[12px] mob:py-[16px]">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="25"
          height="24"
          viewBox="0 0 25 24"
          fill="none"
          class="mob:h-[16px] mob:w-[16px]"
        >
          <path
            d="M24.375 24L0.801777 24C0.690414 24 0.634642 23.8654 0.713388 23.7866L24.2866 0.213387C24.3654 0.134643 24.5 0.190411 24.5 0.301776L24.5 23.875C24.5 23.944 24.444 24 24.375 24Z"
            fill="#147CD1"
          />
        </svg>
        <h1 class="text-[48px] mob:text-center mob:text-[30px] mob:h-[64px] mob:leading-[36px] font-bold leading-[64px] text-[#262626] mob:w-[225px] mob:mt-[-6px]">
          Welcome To My World
        </h1>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="25"
          height="24"
          viewBox="0 0 25 24"
          fill="none"
          class="mob:h-[16px] mob:w-[16px]"
        >
          <path
            d="M0.5 23.875V0.301777C0.5 0.190414 0.634642 0.134642 0.713388 0.213388L24.2866 23.7866C24.3654 23.8654 24.3096 24 24.1982 24H0.625C0.555964 24 0.5 23.944 0.5 23.875Z"
            fill="#147CD1"
          />
        </svg>
      </div>
      <p class="max-w-[1118px] text-center text-[24px] mob:text-[16px] mob:leading-[24px] font-light leading-[32px] text-[#565656]">
        Efficiency and precision are the cornerstone of a successful workflow,
        where collaboration and dedication intertwine to achieve outstanding results
      </p>
    </div>
    <div class="flex mob:flex-col justify-center px-[240px] mob:px-[16px] gap-[24px]">
      <div class="border-solid border-2 border-[#AFAFAF] w-[464px] mob:w-auto">
        <div class="p-[40px] gap-[24px] flex flex-col mob:px-[16px] mob:py-[24px] mob:gap-[16px]">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="64"
            height="64"
            viewBox="0 0 64 64"
            fill="none"
            class="border-solid border-2 border-indigo-400 mob:h-[32px] mob:w-[32px] mob:border-0"
          >
            <path
              d="M32 6.66667V32M32 32L54.6667 19.4072M32 32L9.33333 19.4072M32 32V57.3333M54.6667 44.5926L34.0721 33.1512C33.3158 32.731 32.9377 32.5209 32.5372 32.4386C32.1828 32.3657 31.8172 32.3657 31.4628 32.4386C31.0623 32.5209 30.6842 32.731 29.9279 33.1512L9.33333 44.5926M56 42.8228V21.1772C56 20.2635 56 19.8066 55.8654 19.3992C55.7463 19.0387 55.5516 18.7078 55.2943 18.4286C55.0035 18.1131 54.6041 17.8912 53.8054 17.4475L34.0721 6.48449C33.3158 6.06433 32.9377 5.85426 32.5372 5.77189C32.1828 5.699 31.8172 5.699 31.4628 5.77189C31.0623 5.85426 30.6842 6.06433 29.9279 6.48449L10.1946 17.4475C9.39586 17.8912 8.99649 18.1131 8.70569 18.4286C8.44842 18.7078 8.25373 19.0387 8.13463 19.3992C8 19.8066 8 20.2635 8 21.1772V42.8228C8 43.7365 8 44.1934 8.13463 44.6008C8.25373 44.9613 8.44842 45.2922 8.70569 45.5714C8.99649 45.8869 9.39586 46.1088 10.1946 46.5526L29.9279 57.5155C30.6842 57.9357 31.0623 58.1457 31.4628 58.2281C31.8172 58.301 32.1828 58.301 32.5372 58.2281C32.9377 58.1457 33.3158 57.9357 34.0721 57.5155L53.8054 46.5526C54.6041 46.1088 55.0035 45.8869 55.2943 45.5714C55.5516 45.2922 55.7463 44.9613 55.8654 44.6008C56 44.1934 56 43.7365 56 42.8228Z"
              stroke="#147CD1"
              stroke-width="3"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
          <p class="text-[40px] font-bold leading-[32px] text-[#262626] mob:text-[24px]">
            Creativity
          </p>
          <p class="text-[24px] leading-[32px] text-[#565656] mob:text-[16px] mob:leading-[24px]">
            A businessman's creativity shines through in their capacity to ideate inventive strategies,
            navigating market dynamics with imaginative problem-solving for business growth.
          </p>
        </div>
      </div>
      <div class="border-solid border-2 border-[#AFAFAF] w-[464px] mob:w-auto">
        <div class="p-[40px] gap-[24px] flex flex-col mob:px-[16px] mob:py-[24px] mob:gap-[16px]">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="64"
            height="64"
            viewBox="0 0 64 64"
            fill="none"
            class="mob:h-[32px] mob:w-[32px]"
          >
            <path
              d="M41.4547 26.4678C42.4518 24.6961 43.2833 23.0974 43.7961 21.8805C46.2861 15.9719 43.8239 9.17536 37.8051 6.40297C31.7862 3.63059 25.7423 6.5053 23.0898 12.0558C18.0174 8.57518 11.2511 9.08635 7.51961 14.5179C3.78817 19.9495 4.95926 27.0454 10.07 30.9174C12.3895 32.6747 16.9769 35.2645 21.2958 37.5692M43.4591 31.3332C42.3335 25.2853 37.1875 20.8622 30.7083 22.0644C24.229 23.2666 20.0396 29.1122 20.9155 35.464C21.6192 40.5672 25.5037 52.5406 27.0037 57.0506C27.2084 57.6661 27.3107 57.9738 27.5133 58.1884C27.6898 58.3753 27.9245 58.5108 28.1747 58.5702C28.4618 58.6384 28.7795 58.5732 29.4148 58.4427C34.0706 57.4867 46.3821 54.864 51.1535 52.9219C57.0923 50.5046 60.1571 43.9576 57.8615 37.7413C55.5659 31.525 49.2595 29.284 43.4591 31.3332Z"
              stroke="#147CD1"
              stroke-width="3"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
          <p class="text-[40px] font-bold leading-[32px] text-[#262626] mob:text-[24px]">
            Dedication
          </p>
          <p class="text-[24px] leading-[32px] text-[#565656] mob:text-[16px] mob:leading-[24px]">
            A businessman's dedication is exemplified through tireless efforts, long hours,
            and an unwavering commitment to the success and growth of their enterprise.
          </p>
        </div>
      </div>
      <div class="border-solid border-2 border-[#AFAFAF] w-[464px] mob:w-auto">
        <div class="p-[40px] gap-[24px] flex flex-col mob:px-[16px] mob:py-[24px] mob:gap-[16px]">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="64"
            height="64"
            viewBox="0 0 64 64"
            fill="none"
            class="mob:h-[32px] mob:w-[32px]"
          >
            <path
              d="M29.3333 7.99998H20.8C16.3196 7.99998 14.0794 7.99998 12.3681 8.87193C10.8628 9.63891 9.63893 10.8628 8.87195 12.3681C8 14.0794 8 16.3196 8 20.8V43.2C8 47.6804 8 49.9206 8.87195 51.6319C9.63893 53.1372 10.8628 54.361 12.3681 55.128C14.0794 56 16.3196 56 20.8 56H43.2C47.6804 56 49.9206 56 51.6319 55.128C53.1372 54.361 54.3611 53.1372 55.1281 51.6319C56 49.9206 56 47.6804 56 43.2V34.6666M32 21.3333H42.6667V32M41.3333 9.33331V5.33331M51.8382 12.1617L54.6667 9.33331M54.694 22.6666H58.694M8 35.5923C9.73851 35.8607 11.5197 36 13.3333 36C25.0303 36 35.3742 30.2069 41.6525 21.3333"
              stroke="#147CD1"
              stroke-width="3"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
          <p class="text-[40px] font-bold leading-[32px] text-[#262626] mob:text-[24px]">
            Hard Work
          </p>
          <p class="text-[24px] leading-[32px] text-[#565656] mob:text-[16px] mob:leading-[24px]">
            Hard work is cornerstone of a businessman's success, embodying persistent effort,
            resilience in adversity, an unyielding commitment to achieving & exceeding business objectives.
          </p>
        </div>
      </div>
    </div>
  </div>
</template>
