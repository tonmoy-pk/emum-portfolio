<script setup lang="ts">

</script>

<template>
  <div class="flex items-center justify-center gap-[32px] flex-col py-[100px] mob:py-[64px] mob:px-[16px] mob:flex-col">
    <div class="flex justify-center items-center flex-col gap-[16px] mob:gap-[12px] mob:px-[16px]">
      <div class="flex gap-[24px] items-center mob:items-start mob:gap-[12px] mob:py-[16px]">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="25"
          height="24"
          viewBox="0 0 25 24"
          fill="none"
          class="mob:h-[16px] mob:w-[16px]"
        >
          <path
            d="M24.375 24L0.801777 24C0.690414 24 0.634642 23.8654 0.713388 23.7866L24.2866 0.213387C24.3654 0.134643 24.5 0.190411 24.5 0.301776L24.5 23.875C24.5 23.944 24.444 24 24.375 24Z"
            fill="#147CD1"
          />
        </svg>
        <h1 class="text-[48px] font-bold leading-[64px] text-[#262626] mob:text-center mob:text-[30px] mob:h-[64px] mob:leading-[36px] mob:w-[225px] mob:mt-[-6px]">
          My Business Journey So Far
        </h1>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="25"
          height="24"
          viewBox="0 0 25 24"
          fill="none"
          class="mob:h-[16px] mob:w-[16px]"
        >
          <path
            d="M0.5 23.875V0.301777C0.5 0.190414 0.634642 0.134642 0.713388 0.213388L24.2866 23.7866C24.3654 23.8654 24.3096 24 24.1982 24H0.625C0.555964 24 0.5 23.944 0.5 23.875Z"
            fill="#147CD1"
          />
        </svg>
      </div>
      <p class="max-w-[1118px] text-center text-[24px] font-light leading-[32px] text-[#565656] mob:text-[16px] mob:leading-[24px]">
        My business journey has been a transformative odyssey, navigating challenges,
        embracing opportunities, and evolving to carve a path towards sustained success.
      </p>
    </div>
    <div class="flex justify-center relative mob:h-[1560px]">
      <div class="flex flex-col mob:gap-[270px]">
        <div class="flex items-center relative top-[320px] left-[30px] z-10 mob:left-0 mob:top-[380px]">
          <div class="mob:w-[328px] mob:p-[16px] border-solid border-[1px] border-[#AFAFAF] w-[660px] flex flex-col p-[32px] gap-[24px]">
            <div class="flex flex-col gap-[24px]">
              <div class="flex justify-between items-center self-stretch">
                <div class="h-[100px] flex items-center mob:w-[147px] mob:h-[60px]">
                  <img
                    src="../assets/images/img_6.png"
                    width="286px"
                    height="60px"
                    alt="loading..."
                  >
                </div>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="106"
                  height="12"
                  viewBox="0 0 106 12"
                  fill="none"
                  class="mob:w-[40px]"
                >
                  <path
                    d="M105.333 6C105.333 3.05448 102.946 0.666667 100 0.666667C97.0545 0.666666 94.6667 3.05448 94.6667 6C94.6667 8.94552 97.0545 11.3333 100 11.3333C102.946 11.3333 105.333 8.94552 105.333 6ZM100 5L8.74228e-08 4.99999L-8.74228e-08 6.99999L100 7L100 5Z"
                    fill="#FF563F"
                  />
                </svg>
                <div class="mob:text-[24px] mob:leading-[32px] mob:px-[16px] border-solid border-[1.5px] border-black text-[36px] leading-[48px] px-[32px]">
                  <h1>2022</h1>
                </div>
              </div>
              <p class="text-[20px] leading-[28px] text-[#565656] mob:text-[16px] mob:leading-[24px]">
                Jicson, a leading Bangladeshi electronics brand, proudly integrates the finest Korean technology globally, combining innovation and quality to deliver cutting-edge electronic products.
                With a commitment to excellence, Jicson brings the best of both worlds to its customers.
              </p>
            </div>
            <div>
              <button class="flex items-center gap-[10px] leading-[24px] text-[16px] border-solid border-[1px] border-black px-[16px] py-[12px]">
                Explore Now
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 16 16"
                  fill="none"
                >
                  <path
                    d="M4.00016 4V5.33333H9.72683L3.3335 11.7267L4.2735 12.6667L10.6668 6.27333V12H12.0002V4H4.00016Z"
                    fill="#262626"
                  />
                </svg>
              </button>
            </div>
          </div>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="78"
            height="32"
            viewBox="0 0 78 32"
            fill="none"
            class="mob:hidden"
          >
            <rect
              opacity="0.3"
              x="61.5"
              y="32"
              width="61"
              height="32"
              transform="rotate(-180 61.5 32)"
              fill="url(#paint0_linear_354_1354)"
            />
            <circle
              cx="61.5"
              cy="16"
              r="16"
              transform="rotate(-180 61.5 16)"
              fill="white"
            />
            <circle
              cx="61.5"
              cy="16"
              r="8"
              transform="rotate(-180 61.5 16)"
              fill="#FF563F"
            />
            <defs>
              <linearGradient
                id="paint0_linear_354_1354"
                x1="61.5"
                y1="52"
                x2="173"
                y2="52"
                gradientUnits="userSpaceOnUse"
              >
                <stop stop-color="#FF563F" />
                <stop
                  offset="1"
                  stop-color="white"
                  stop-opacity="0"
                />
              </linearGradient>
            </defs>
          </svg>
        </div>
        <div class="flex items-center relative top-[550px] left-[29px] mob:left-0 z-10">
          <div class="mob:w-[328px] mob:p-[16px] border-solid border-[1px] border-[#AFAFAF] w-[660px] flex flex-col p-[32px] gap-[24px]">
            <div class="flex flex-col gap-[24px]">
              <div class="flex justify-between items-center self-stretch">
                <div class="h-[100px] flex items-center mob:w-[147px] mob:h-[60px]">
                  <img
                    src="../assets/images/img_3.png"
                    width="286px"
                    height="60px"
                    alt="loading..."
                  >
                </div>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="106"
                  height="12"
                  viewBox="0 0 106 12"
                  fill="none"
                  class="mob:w-[40px]"
                >
                  <path
                    d="M105.333 6C105.333 3.05448 102.945 0.666667 99.9998 0.666667C97.0542 0.666666 94.6664 3.05448 94.6664 6C94.6664 8.94552 97.0542 11.3333 99.9998 11.3333C102.945 11.3333 105.333 8.94552 105.333 6ZM99.9998 5L-0.000244053 4.99999L-0.000244228 6.99999L99.9998 7L99.9998 5Z"
                    fill="#1476BF"
                  />
                </svg>
                <div class="mob:text-[24px] mob:leading-[32px] mob:px-[16px] border-solid border-[1.5px] border-black text-[36px] leading-[48px] px-[32px]">
                  <h1>2006</h1>
                </div>
              </div>
              <p class="text-[20px] leading-[28px] text-[#565656] mob:text-[16px] mob:leading-[24px]">
                AC Service is a leading AC & AC spare parts Sales, AC installation, AC repair & AC Rent company in Bangladesh. AC Service started its journey in 2006. AC Service has an expert team and well-known engineers.
                AC Service hopes is to achieve any challenging goal in the AC field.
              </p>
            </div>
            <div>
              <button class="flex items-center gap-[10px] leading-[24px] text-[16px] border-solid border-[1px] border-black px-[16px] py-[12px] mob:leading-[16px]">
                Explore Now
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 16 16"
                  fill="none"
                >
                  <path
                    d="M4.00016 4V5.33333H9.72683L3.3335 11.7267L4.2735 12.6667L10.6668 6.27333V12H12.0002V4H4.00016Z"
                    fill="#262626"
                  />
                </svg>
              </button>
            </div>
          </div>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="78"
            height="32"
            viewBox="0 0 78 32"
            fill="none"
            class="mob:hidden"
          >
            <rect
              opacity="0.3"
              x="61.4998"
              y="32"
              width="61"
              height="32"
              transform="rotate(-180 61.4998 32)"
              fill="url(#paint0_linear_354_1409)"
            />
            <circle
              cx="61.4998"
              cy="16"
              r="16"
              transform="rotate(-180 61.4998 16)"
              fill="white"
            />
            <circle
              cx="61.4998"
              cy="16"
              r="8"
              transform="rotate(-180 61.4998 16)"
              fill="#1476BF"
            />
            <defs>
              <linearGradient
                id="paint0_linear_354_1409"
                x1="61.4998"
                y1="52"
                x2="173"
                y2="52"
                gradientUnits="userSpaceOnUse"
              >
                <stop stop-color="#1476BF" />
                <stop
                  offset="1"
                  stop-color="white"
                  stop-opacity="0"
                />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
      <div class=" flex flex-col items-center justify-center relative mob:hidden">
        <div class="h-[24px] w-[24px] rounded-3xl bg-blue-700" />
        <div class="border-solid border-2 line border-indigo-600 h-[1352px]" />
        <div class="h-[24px] w-[24px] rounded-3xl bg-black" />
      </div>
      <div class="flex flex-col gap-[300px] mob:gap-[480px] mob:absolute">
        <div class="flex items-center relative top-[25px] left-[-28px] z-10 mob:left-0">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="77"
            height="32"
            viewBox="0 0 77 32"
            fill="none"
            class="mob:hidden"
          >
            <rect
              opacity="0.3"
              x="16"
              width="61"
              height="32"
              fill="url(#paint0_linear_354_1238)"
            />
            <circle
              cx="16"
              cy="16"
              r="16"
              fill="white"
            />
            <circle
              cx="16"
              cy="16"
              r="8"
              fill="#178EEF"
            />
            <defs>
              <linearGradient
                id="paint0_linear_354_1238"
                x1="16"
                y1="20"
                x2="127.5"
                y2="20"
                gradientUnits="userSpaceOnUse"
              >
                <stop stop-color="#178EEF" />
                <stop
                  offset="1"
                  stop-color="white"
                  stop-opacity="0"
                />
              </linearGradient>
            </defs>
          </svg>
          <div class="mob:w-[328px] mob:p-[16px] journey-card-body border-solid border-[1px] border-[#AFAFAF] w-[660px] flex flex-col p-[32px] gap-[24px] ">
            <div class="flex flex-col gap-[24px]">
              <div class="flex justify-between items-center self-stretch">
                <div class="h-[100px] flex items-center mob:w-[147px] mob:h-[60px]">
                  <img
                    src="../assets/images/img_7.png"
                    width="286px"
                    height="98px"
                    alt="loading..."
                    class="mob:w-[147px] mob:h-[60px]"
                  >
                </div>
                <div class="flex items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="106"
                    height="12"
                    viewBox="0 0 106 12"
                    fill="none"
                    class="mob:w-[40px]"
                  >
                    <path
                      d="M105.333 6C105.333 3.05448 102.946 0.666667 100 0.666667C97.0545 0.666666 94.6667 3.05448 94.6667 6C94.6667 8.94552 97.0545 11.3333 100 11.3333C102.946 11.3333 105.333 8.94552 105.333 6ZM100 5L8.74228e-08 4.99999L-8.74228e-08 6.99999L100 7L100 5Z"
                      fill="#178EEF"
                    />
                  </svg>
                </div>
                <div class="mob:text-[24px] mob:leading-[32px] mob:px-[16px] border-solid border-[1.5px] border-black text-[36px] leading-[48px] px-[32px]">
                  2023
                </div>
              </div>
              <p class="text-[20px] leading-[28px] text-[#565656] mob:text-[16px] mob:leading-[24px]">
                Jicson Travel is a dynamic and customer-focused travel agency that offers a wide range of travel
                services, including flight bookings, hotel booking, Visa, Car Rent, accommodations, vacation packages,
                and personalized travel itineraries.
              </p>
            </div>
            <div>
              <button class="flex items-center gap-[10px] leading-[24px] text-[16px] border-solid border-[1px] border-black px-[16px] py-[12px] mob:leading-[16px]">
                Explore Now
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 16 16"
                  fill="none"
                >
                  <path
                    d="M4.00016 4V5.33333H9.72683L3.3335 11.7267L4.2735 12.6667L10.6668 6.27333V12H12.0002V4H4.00016Z"
                    fill="#262626"
                  />
                </svg>
              </button>
            </div>
          </div>
        </div>
        <div class="flex items-center relative top-[-35px] left-[-30px] z-10 mob:left-0">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="78"
            height="32"
            viewBox="0 0 78 32"
            fill="none"
            class="mob:hidden"
          >
            <rect
              opacity="0.3"
              x="16.5005"
              width="61"
              height="32"
              fill="url(#paint0_linear_354_1274)"
            />
            <circle
              cx="16.5005"
              cy="16"
              r="16"
              fill="white"
            />
            <circle
              cx="16.5005"
              cy="16"
              r="8"
              fill="#ED0314"
            />
            <defs>
              <linearGradient
                id="paint0_linear_354_1274"
                x1="16.5005"
                y1="20"
                x2="128"
                y2="20"
                gradientUnits="userSpaceOnUse"
              >
                <stop stop-color="#ED0314" />
                <stop
                  offset="1"
                  stop-color="white"
                  stop-opacity="0"
                />
              </linearGradient>
            </defs>
          </svg>
          <div class="mob:w-[328px] mob:p-[16px] journey-card-body border-solid border-[1px] border-[#AFAFAF] w-[660px] flex flex-col p-[32px] gap-[24px]">
            <div class="flex flex-col gap-[24px]">
              <div class="flex justify-between items-center self-stretch">
                <div class="h-[100px] flex items-center mob:w-[147px] mob:h-[60px]">
                  <img
                    src="../assets/images/img_4.png"
                    width="286px"
                    height="70px"
                    alt="loading..."
                  >
                </div>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="106"
                  height="12"
                  viewBox="0 0 106 12"
                  fill="none"
                  class="mob:w-[40px]"
                >
                  <path
                    d="M105.334 6C105.334 3.05448 102.946 0.666667 100 0.666667C97.055 0.666666 94.6672 3.05448 94.6672 6C94.6672 8.94552 97.055 11.3333 100 11.3333C102.946 11.3333 105.334 8.94552 105.334 6ZM100 5L0.000488369 4.99999L0.000488194 6.99999L100 7L100 5Z"
                    fill="#ED0314"
                  />
                </svg>
                <div class="mob:text-[24px] mob:leading-[32px] mob:px-[16px] border-solid border-[1.5px] border-black text-[36px] leading-[48px] px-[32px]">
                  <h1>2016</h1>
                </div>
              </div>
              <p class="text-[20px] leading-[28px] text-[#565656] mob:text-[16px] mob:leading-[24px]">
                Launched in 2016, Ponnomela is a trusted one-stop shopping destination in Bangladesh, emphasizing "Delivering Happiness" through its extensive range of electronics & household appliances, efficient doorstep delivery,
                fostering strong connections with vendors thousands of consumers across country.
              </p>
            </div>
            <div>
              <button class="mob:leading-[16px] flex items-center gap-[10px] leading-[24px] text-[16px] border-solid border-[1px] border-black px-[16px] py-[12px]">
                Explore Now
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 16 16"
                  fill="none"
                >
                  <path
                    d="M4.00016 4V5.33333H9.72683L3.3335 11.7267L4.2735 12.6667L10.6668 6.27333V12H12.0002V4H4.00016Z"
                    fill="#262626"
                  />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<style>
.hello {
  display: none;
}
</style>
